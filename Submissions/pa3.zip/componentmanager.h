#ifndef COMPONENTMANAGER_H
#define COMPONENTMANAGER_H


class componentManager
{
public:
    componentManager();
};

#endif // COMPONENTMANAGER_H